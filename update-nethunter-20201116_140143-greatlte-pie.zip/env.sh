#!/sbin/sh
export LIBDIR=/system/lib64
export ARCH=arm64
